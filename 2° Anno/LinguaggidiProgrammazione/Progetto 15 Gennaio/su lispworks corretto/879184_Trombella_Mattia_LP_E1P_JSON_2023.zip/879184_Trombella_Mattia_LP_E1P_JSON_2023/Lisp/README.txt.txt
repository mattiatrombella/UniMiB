Gruppo formato da: 
	- Romeo Francesco matr. 885880
	- Trombella Mattia matr. 879184

